const express = require("express");
const { join } = require("path");
const dotenv = require("dotenv").config();
const app = express();

app.get('/login', (req, res) => {
    res.send('Hello World!');
});




const PORT = 3000;

app.listen(PORT , ()=>{
    console.log("Server is listening ")
})
// docker build -t app .
//docker run -d -p 6565:3000 --name my-cont app












